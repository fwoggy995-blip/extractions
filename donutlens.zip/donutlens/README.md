# DonutLens (Fabric, Minecraft 1.21.11)

Client-side price-book + tooltips + flip calculator for DonutSMP.

## Build
1. Check https://fabricmc.net/develop/ for 1.21.11 and update `gradle.properties`
   (yarn_mappings, loader_version, fabric_version).
2. Add a Gradle wrapper (`gradle wrapper --gradle-version 9.2`) or use the Fabric template's wrapper.
3. `./gradlew build` -> jar in `build/libs/`.

## Commands
- `/dl set item <id> <price>`        e.g. `/dl set item diamond 250`
- `/dl set spawner <type> <price>`   e.g. `/dl set spawner skeleton 5m`
- `/dl set shop <id> <price>`        /shop sell price (used by the footer, coming next)
- `/dl set ref <type>`               spawner used for the "= X spawners" line
- `/dl set tax <percent>`            default 2
- `/dl remove <key>` / `/dl list`
- `/dl flip <buy> <sell>`            net profit, margin, break-even after tax

Prices accept `k`, `m`, `b` suffixes. Data is stored in `config/donutlens.json`.

## Status
- [x] Price-book + `/dl set`
- [x] Tooltip: per-item, stack value, spawner equivalent
- [x] Tax & margin calculator (`/dl flip`)
- [ ] Container net-worth header
- [ ] Inventory sell-value footer
