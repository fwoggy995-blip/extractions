package com.donutlens;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class DonutLensClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("donutlens");

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register(this::registerCommands);
        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> addTooltip(stack, lines));
    }

    // ------------------------------------------------------------ tooltip

    /** Returns price for a single unit of this stack, or NaN if unknown. */
    private static double unitPrice(ItemStack stack) {
        PriceBook pb = PriceBook.get();
        if (stack.isOf(Items.SPAWNER)) {
            String type = spawnerType(stack);
            Double p = pb.spawners.get(type);
            return p == null ? Double.NaN : p;
        }
        Double p = pb.items.get(Registries.ITEM.getId(stack.getItem()).toString());
        return p == null ? Double.NaN : p;
    }

    /**
     * Derives spawner type from the item's display name, e.g. "Skeleton Spawner" -> "skeleton".
     * Servers often rename spawners, so we go by name. Adjust if DonutSMP's naming differs.
     */
    static String spawnerType(ItemStack stack) {
        String name = Formatting.strip(stack.getName().getString());
        if (name == null) return "unknown";
        return name.toLowerCase().replace("spawner", "").trim();
    }

    private void addTooltip(ItemStack stack, java.util.List<Text> lines) {
        if (stack.isEmpty()) return;
        double unit = unitPrice(stack);
        if (Double.isNaN(unit)) return;

        PriceBook pb = PriceBook.get();
        int count = stack.getCount();

        lines.add(Text.literal("Price: $" + Money.format(unit) + " each").formatted(Formatting.GOLD));
        if (count > 1) {
            lines.add(Text.literal("Stack (" + count + "): $" + Money.format(unit * count))
                    .formatted(Formatting.YELLOW));
        }

        Double ref = pb.spawners.get(pb.referenceSpawner);
        if (ref != null && ref > 0) {
            double eq = (unit * count) / ref;
            lines.add(Text.literal(String.format("= %.2f %s spawners", eq, pb.referenceSpawner))
                    .formatted(Formatting.GRAY));
        }
    }

    // ----------------------------------------------------------- commands

    private void registerCommands(CommandDispatcher<FabricClientCommandSource> d, CommandRegistryAccess access) {
        d.register(literal("dl")
                .then(literal("set")
                        .then(literal("item")
                                .then(argument("id", StringArgumentType.word())
                                        .then(argument("price", StringArgumentType.word())
                                                .executes(ctx -> setPrice(ctx.getSource(), "item",
                                                        StringArgumentType.getString(ctx, "id"),
                                                        StringArgumentType.getString(ctx, "price"))))))
                        .then(literal("spawner")
                                .then(argument("type", StringArgumentType.word())
                                        .then(argument("price", StringArgumentType.word())
                                                .executes(ctx -> setPrice(ctx.getSource(), "spawner",
                                                        StringArgumentType.getString(ctx, "type"),
                                                        StringArgumentType.getString(ctx, "price"))))))
                        .then(literal("shop")
                                .then(argument("id", StringArgumentType.word())
                                        .then(argument("price", StringArgumentType.word())
                                                .executes(ctx -> setPrice(ctx.getSource(), "shop",
                                                        StringArgumentType.getString(ctx, "id"),
                                                        StringArgumentType.getString(ctx, "price"))))))
                        .then(literal("ref")
                                .then(argument("type", StringArgumentType.word())
                                        .executes(ctx -> {
                                            PriceBook pb = PriceBook.get();
                                            pb.referenceSpawner = StringArgumentType.getString(ctx, "type").toLowerCase();
                                            pb.save();
                                            msg(ctx.getSource(), "Reference spawner: " + pb.referenceSpawner);
                                            return 1;
                                        })))
                        .then(literal("tax")
                                .then(argument("percent", StringArgumentType.word())
                                        .executes(ctx -> {
                                            double pct = Money.parse(StringArgumentType.getString(ctx, "percent"));
                                            if (Double.isNaN(pct) || pct < 0 || pct >= 100) {
                                                msg(ctx.getSource(), "Invalid percent.");
                                                return 0;
                                            }
                                            PriceBook pb = PriceBook.get();
                                            pb.taxRate = pct / 100.0;
                                            pb.save();
                                            msg(ctx.getSource(), "Tax set to " + pct + "%");
                                            return 1;
                                        }))))
                .then(literal("remove")
                        .then(argument("key", StringArgumentType.word())
                                .executes(ctx -> {
                                    String key = StringArgumentType.getString(ctx, "key").toLowerCase();
                                    PriceBook pb = PriceBook.get();
                                    boolean removed = pb.items.remove(PriceBook.normalizeId(key)) != null;
                                    removed |= pb.spawners.remove(key) != null;
                                    removed |= pb.shop.remove(PriceBook.normalizeId(key)) != null;
                                    pb.save();
                                    msg(ctx.getSource(), removed ? "Removed " + key : "Nothing found for " + key);
                                    return removed ? 1 : 0;
                                })))
                .then(literal("list").executes(ctx -> {
                    PriceBook pb = PriceBook.get();
                    FabricClientCommandSource s = ctx.getSource();
                    msg(s, "Items:");
                    for (Map.Entry<String, Double> e : pb.items.entrySet())
                        msg(s, "  " + e.getKey() + " = $" + Money.format(e.getValue()));
                    msg(s, "Spawners:");
                    for (Map.Entry<String, Double> e : pb.spawners.entrySet())
                        msg(s, "  " + e.getKey() + " = $" + Money.format(e.getValue()));
                    msg(s, "Shop sell prices:");
                    for (Map.Entry<String, Double> e : pb.shop.entrySet())
                        msg(s, "  " + e.getKey() + " = $" + Money.format(e.getValue()));
                    msg(s, "Tax: " + (pb.taxRate * 100) + "%  Reference spawner: " + pb.referenceSpawner);
                    return 1;
                }))
                .then(literal("flip")
                        .then(argument("buy", StringArgumentType.word())
                                .then(argument("sell", StringArgumentType.word())
                                        .executes(ctx -> {
                                            double buy = Money.parse(StringArgumentType.getString(ctx, "buy"));
                                            double sell = Money.parse(StringArgumentType.getString(ctx, "sell"));
                                            if (Double.isNaN(buy) || Double.isNaN(sell)) {
                                                msg(ctx.getSource(), "Invalid numbers. Try e.g. 1.5m or 250k.");
                                                return 0;
                                            }
                                            PriceBook pb = PriceBook.get();
                                            double net = pb.net(sell);
                                            double profit = pb.profit(buy, sell);
                                            double margin = buy > 0 ? profit / buy * 100 : 0;
                                            FabricClientCommandSource s = ctx.getSource();
                                            msg(s, "Buy: $" + Money.format(buy) + "  Sell: $" + Money.format(sell));
                                            msg(s, "After " + (pb.taxRate * 100) + "% tax you receive: $" + Money.format(net));
                                            msg(s, (profit >= 0 ? "Profit: $" : "Loss: -$") + Money.format(Math.abs(profit))
                                                    + String.format(" (%.1f%%)", margin));
                                            msg(s, "Break-even sell price: $" + Money.format(pb.breakEven(buy)));
                                            return 1;
                                        })))));
    }

    private int setPrice(FabricClientCommandSource src, String kind, String key, String priceStr) {
        double price = Money.parse(priceStr);
        if (Double.isNaN(price) || price < 0) {
            msg(src, "Invalid price. Try e.g. 1500, 1.5k, 2m.");
            return 0;
        }
        PriceBook pb = PriceBook.get();
        switch (kind) {
            case "item" -> pb.items.put(PriceBook.normalizeId(key), price);
            case "shop" -> pb.shop.put(PriceBook.normalizeId(key), price);
            case "spawner" -> pb.spawners.put(key.toLowerCase(), price);
            default -> { return 0; }
        }
        pb.save();
        msg(src, "Set " + kind + " " + key + " = $" + Money.format(price));
        return 1;
    }

    private static void msg(FabricClientCommandSource src, String s) {
        src.sendFeedback(Text.literal("[DL] ").formatted(Formatting.GOLD).append(Text.literal(s).formatted(Formatting.WHITE)));
    }
}
