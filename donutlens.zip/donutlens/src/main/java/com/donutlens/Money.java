package com.donutlens;

public final class Money {
    private Money() {}

    /** Parses "1500", "1.5k", "2m", "3b". Returns NaN if invalid. */
    public static double parse(String s) {
        if (s == null || s.isEmpty()) return Double.NaN;
        s = s.trim().toLowerCase().replace(",", "").replace("$", "");
        double mult = 1;
        char last = s.charAt(s.length() - 1);
        switch (last) {
            case 'k' -> mult = 1_000d;
            case 'm' -> mult = 1_000_000d;
            case 'b' -> mult = 1_000_000_000d;
            default -> {}
        }
        if (mult != 1) s = s.substring(0, s.length() - 1);
        try {
            return Double.parseDouble(s) * mult;
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    public static String format(double v) {
        double a = Math.abs(v);
        if (a >= 1_000_000_000d) return trim(v / 1_000_000_000d) + "B";
        if (a >= 1_000_000d) return trim(v / 1_000_000d) + "M";
        if (a >= 1_000d) return trim(v / 1_000d) + "K";
        return trim(v);
    }

    private static String trim(double v) {
        String s = String.format("%.2f", v);
        if (s.contains(".")) s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }
}
