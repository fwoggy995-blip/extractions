package com.donutlens;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;

public class PriceBook {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("donutlens.json");

    /** Market price per single item, keyed by item id, e.g. "minecraft:diamond". */
    public Map<String, Double> items = new TreeMap<>();
    /** Market price per spawner, keyed by lowercase type, e.g. "skeleton". */
    public Map<String, Double> spawners = new TreeMap<>();
    /** /shop sell price per single item (for the inventory sell-value footer, later). */
    public Map<String, Double> shop = new TreeMap<>();
    /** Spawner type used for the "spawner equivalent" line. */
    public String referenceSpawner = "skeleton";
    /** Tax applied on sales (0.02 = 2%). */
    public double taxRate = 0.02;

    private static PriceBook instance;

    public static PriceBook get() {
        if (instance == null) instance = load();
        return instance;
    }

    private static PriceBook load() {
        try {
            if (Files.exists(FILE)) {
                PriceBook pb = GSON.fromJson(Files.readString(FILE), PriceBook.class);
                if (pb != null) return pb;
            }
        } catch (Exception e) {
            DonutLensClient.LOGGER.error("Failed to load price book", e);
        }
        return new PriceBook();
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            DonutLensClient.LOGGER.error("Failed to save price book", e);
        }
    }

    // ---- tax / flip math ----

    /** What you actually receive after tax. */
    public double net(double sell) { return sell * (1 - taxRate); }

    /** Profit from buying at `buy` and selling at `sell` after tax. */
    public double profit(double buy, double sell) { return net(sell) - buy; }

    /** Minimum sell price to break even on `buy`. */
    public double breakEven(double buy) { return buy / (1 - taxRate); }

    public static String normalizeId(String id) {
        id = id.toLowerCase();
        return id.contains(":") ? id : "minecraft:" + id;
    }
}
